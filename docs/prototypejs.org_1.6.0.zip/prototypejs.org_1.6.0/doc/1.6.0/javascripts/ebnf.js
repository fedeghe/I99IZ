CodeHighlighter.addStyle("ebnf",{
	method : {
		exp  : /^(\w+)/
	},
	brackets : {
		exp  : /\(|\)/
	},
        arrow : {
                exp: /\-&gt;/
        },
	'return' : {
		exp  : /\w+$/
	}
});